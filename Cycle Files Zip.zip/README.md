# The Cycle — Understanding Coercive Control & Trauma Bonding

A free, offline-capable educational web app about the patterns of coercive control (often called "narcissistic abuse"), trauma bonding, and recovery. Designed to be added to a phone home screen and read like a small book.

**[→ Read it live](https://YOUR-USERNAME.github.io/the-cycle/)** *(replace with your link once published — see below)*

---

## What this is

A single, self-contained HTML page. No tracking, no ads, no accounts, no internet required after first load. It explains:

- The four-phase cycle (idealize, devalue, discard, hoover) and how each phase *feels* from inside it
- Why the harm happens — presented as explanatory models, not as a diagnosis
- What "narcissistic supply" means and why empathy is so often the thing exploited
- Why the pattern can't be fixed by loving harder
- Why leaving is so difficult — the neurobiology, not weakness
- Signs you may be in it
- Crisis and support resources

## What this is NOT

- **Not a diagnosis.** "Narcissistic abuse" is not a clinical term. This describes a *pattern of behaviour*, not a medical condition, and you do not need to label anyone to recognise harm.
- **Not a substitute for professional help.** It points toward support; it does not replace it.
- **Not a tool for diagnosing another person.** It is written for the person experiencing the pattern.

## Accuracy

This version (v2) was fact-checked against current sources and corrected. See `SOURCES_AND_CORRECTIONS.md` for the full list of what changed and why, including the statistics that were removed or softened.

## Files

| File | Purpose |
|------|---------|
| `index.html` | The app itself (rename of `TheCycle.html`) |
| `SOURCES_AND_CORRECTIONS.md` | Citations + record of corrections from v1 |
| `README.md` | This file |

## License

Released for free educational use. Share it freely. If you adapt it, please keep the "not a diagnosis / not a substitute for care" framing intact — it matters for the people who will read it.

---

*If you are in immediate danger, call 911 (US). National DV Hotline: 1-800-799-7233, or text START to 88788.*
