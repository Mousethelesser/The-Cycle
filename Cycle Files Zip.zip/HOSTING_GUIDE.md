# How to Host & Share This (Plain-English Guide)

You have a single file (`index.html`) that is a complete website. Here are your options for putting it online, from easiest to most permanent. Pick one — you don't need all of them.

---

## OPTION 1 — GitHub Pages (free, permanent, recommended)

This gives you a real, shareable web link like `https://yourname.github.io/the-cycle/` that works forever, for free, with no ads. About 10 minutes the first time.

### Step 1 — Make a GitHub account
1. Go to **github.com** and click **Sign up**. It's free.
2. Pick a username (this becomes part of your link, so choose something you're okay with being public — e.g. `jsmith` gives `jsmith.github.io`).

### Step 2 — Create a repository ("repo" = a project folder)
1. Once logged in, click the **+** in the top-right corner → **New repository**.
2. **Repository name:** type `the-cycle` (this becomes the end of your link).
3. Set it to **Public**.
4. Check the box **"Add a README file."**
5. Click **Create repository**.

### Step 3 — Upload your files
1. On your new repo page, click **Add file** → **Upload files**.
2. Drag in these files from the folder I gave you:
   - `index.html`  ← **this one is essential** (it's the website)
   - `README.md` (optional — it overwrites the default readme)
   - `SOURCES_AND_CORRECTIONS.md` (optional but nice to include)
3. Scroll down, click **Commit changes**.

### Step 4 — Turn on GitHub Pages
1. In your repo, click **Settings** (top menu).
2. In the left sidebar, click **Pages**.
3. Under **"Build and deployment" → "Source,"** choose **Deploy from a branch**.
4. Under **Branch**, select **main** and **/ (root)**, then click **Save**.
5. Wait 1–2 minutes. Refresh the page. A green banner will show your live link:
   **`https://YOURNAME.github.io/the-cycle/`**

That link is now public and shareable. Done.

### Step 5 — Update the README link (optional)
Edit `README.md` and replace `YOUR-USERNAME` with your real username so the "Read it live" link works.

---

## OPTION 2 — Netlify Drop (fastest, no account math)

If GitHub feels like too much, this is the absolute fastest way:

1. Go to **app.netlify.com/drop**
2. Drag your `index.html` file (or the whole folder) onto the page.
3. It instantly gives you a live link like `https://random-name-123.netlify.app`.
4. (Optional) Make a free account to keep the link permanent and rename it.

That's it — no repo, no settings. The tradeoff: the free random link can expire if you don't claim it with an account.

---

## OPTION 3 — Just send the file (no hosting at all)

The file works on its own. You can:
- **Email it** to someone as an attachment — they open it in any browser.
- **AirDrop** it to another iPhone/Mac.
- **Put it in iCloud Drive / Google Drive / Dropbox** and share the link. (Note: some cloud viewers show the raw code instead of the page; if that happens, the person should download it first, then open it.)

The downside of this option is there's no clean web link, and people have to manage a file. For sharing widely, Option 1 or 2 is better.

---

## Adding it to an iPhone Home Screen

Once it's online (Option 1 or 2), anyone can install it like an app:

1. Open the link in **Safari** (must be Safari, not Chrome, for the home-screen feature).
2. Tap the **Share** button (the square with an arrow).
3. Scroll down → tap **Add to Home Screen**.
4. Name it (e.g. "The Cycle") → tap **Add**.

It now opens full-screen, like an app, and works offline after the first open.

---

## A safety note worth knowing

If you're sharing this with someone who may still be in a controlling relationship: a new app icon or browser history can be noticed by an abusive partner. Two safer options for those readers:
- Bookmark it under an unremarkable name, or
- Just read it in a private/incognito browser tab and don't save it.

The live site itself stores nothing and tracks nothing, so there's no account or login that could be discovered.

---

## Which should you pick?

- **Want a real link to share publicly and keep forever?** → Option 1 (GitHub Pages).
- **Want it online in 60 seconds and don't care about a pretty link?** → Option 2 (Netlify Drop).
- **Just sending it to one or two people?** → Option 3 (email/AirDrop).

If you go with GitHub and hit a snag at any step, tell me which step number and what you see on screen, and I'll walk you through it.
